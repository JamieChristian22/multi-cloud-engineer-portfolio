# AWS Diagram Instructions

Use the Mermaid file `aws-enterprise-web-platform.mmd` to create the architecture diagram in Draw.io, Lucidchart, or GitHub Mermaid preview.

## Diagram Title

AWS Enterprise Web Platform

## Required Components

- Internet User
- Internet
- Internet Gateway
- VPC `10.10.0.0/16`
- Public Subnet `10.10.1.0/24`
- EC2 Web Server
- Security Group
- IAM Role
- S3 Bucket
- CloudWatch Dashboard
- CloudWatch Alarm
- SNS Topic
- Administrator Email
- CloudTrail
- CloudTrail S3 Log Bucket

## Export Name

```text
architecture/exports/aws-enterprise-web-platform.png
```
