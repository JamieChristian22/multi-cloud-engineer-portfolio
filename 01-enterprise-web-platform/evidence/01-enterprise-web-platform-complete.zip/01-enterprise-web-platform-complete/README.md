# Project 01 — Enterprise Web Platform

## Project Summary

This project documents the design and deployment of an enterprise-style web application platform using AWS as the completed implementation and Azure/GCP as equivalent provider designs for multi-cloud engineering alignment.

The AWS implementation includes custom networking, compute, web hosting, secure storage, identity access management, monitoring, alerting, notification delivery, and audit logging.

## Business Scenario

Acme Retail Solutions needs a secure cloud platform to host a customer-facing web application. The company wants a repeatable design that can be implemented across AWS, Microsoft Azure, and Google Cloud Platform while maintaining consistent security, monitoring, and operational standards.

The organization needs to solve the following problems:

- Web application hosting needs to be separated from the default cloud network.
- Administrators need secure access to the application server.
- Storage must be private, encrypted, and version-controlled.
- Cloud activity must be logged for auditing and troubleshooting.
- Platform health must be monitored with dashboards and alarms.
- Alerts must be delivered to administrators when infrastructure conditions exceed operational thresholds.
- The project must be documented well enough for a cloud engineering portfolio and interview discussion.

## Architecture Overview

### AWS Implementation

The AWS deployment uses a custom VPC with a public subnet, Internet Gateway, public route table, EC2 instance, Apache web server, security group, S3 bucket, IAM role, CloudWatch, SNS, and CloudTrail.

Traffic flow:

```text
Internet User
    ↓
Public IPv4 Address
    ↓
Security Group allowing HTTP/HTTPS
    ↓
EC2 Instance in Public Subnet
    ↓
Apache Web Server
```

Supporting services:

```text
EC2 → IAM Role → CloudWatch Monitoring
CloudWatch Alarm → SNS Email Notification
CloudTrail → S3 Audit Log Bucket
S3 → Private Encrypted Object Storage
```

## AWS Services Implemented

| Service | Purpose |
|---|---|
| Amazon VPC | Isolated network boundary for the web platform |
| Public Subnet | Hosts the public EC2 web server |
| Internet Gateway | Provides internet access to the public subnet |
| Route Table | Routes public internet traffic through the Internet Gateway |
| Security Group | Controls inbound and outbound traffic to EC2 |
| EC2 | Hosts the Apache web application |
| Amazon Linux 2023 | Operating system for the EC2 server |
| Apache HTTP Server | Serves the custom web page |
| Amazon S3 | Provides secure object storage |
| IAM Role | Allows EC2 to access AWS services without static credentials |
| CloudWatch Dashboard | Visualizes CPU, network, and status metrics |
| CloudWatch Alarm | Detects high CPU usage |
| Amazon SNS | Sends alert notifications by email |
| AWS CloudTrail | Records account activity and API events |

## Completed AWS Resource Naming

| Resource Type | Resource Name |
|---|---|
| VPC | `enterprise-web-vpc` |
| Public Subnet | `enterprise-web-public-subnet` |
| Internet Gateway | `enterprise-web-igw` |
| Public Route Table | `enterprise-web-public-rt` |
| Security Group | `enterprise-web-sg` |
| EC2 Instance | `enterprise-web-ec2` |
| Key Pair | `enterprise-web-key-2.pem` |
| S3 Storage Bucket | `enterprise-web-storage-jcii-001` or project-specific unique name |
| IAM Role | `enterprise-web-ec2-monitoring-role` |
| CloudWatch Dashboard | `enterprise-web-dashboard` |
| CloudWatch Alarm | `enterprise-web-high-cpu-alarm` |
| SNS Topic | `enterprise-web-alerts` |
| CloudTrail Trail | `enterprise-web-cloudtrail` |
| CloudTrail Log Bucket | `enterprise-web-cloudtrail-logs-jcii` |

## Security Controls

This project includes multiple security controls:

- SSH access controlled through key pair authentication.
- SSH restricted through Security Group rules.
- HTTP/HTTPS explicitly allowed for application traffic.
- EC2 uses an IAM role instead of stored access keys.
- S3 Block Public Access enabled.
- S3 versioning enabled.
- S3 server-side encryption enabled.
- CloudTrail enabled for audit logging.
- CloudWatch alarms configured for operational monitoring.
- SNS email confirmation required before alert delivery.

## Monitoring and Alerting

The CloudWatch dashboard monitors:

- EC2 CPU Utilization
- Network In
- Network Out
- Status Check Failed

The CloudWatch alarm monitors:

- Metric: EC2 `CPUUtilization`
- Threshold: Greater than 70%
- Period: 5 minutes
- Notification: Amazon SNS email topic

## Evidence Screenshots

The expected AWS evidence set is listed in `evidence/aws-evidence-index.md`.

Primary screenshots include:

- VPC creation
- Public subnet
- Internet Gateway
- Route Table
- Security Group
- EC2 running
- SSH session
- Apache running
- Live web application
- S3 secure storage
- IAM role attached
- CloudWatch dashboard
- CloudWatch alarm
- SNS topic
- SNS subscription
- SNS test email
- CloudTrail trail
- CloudTrail event history

## Folder Structure

```text
01-enterprise-web-platform
├── README.md
├── architecture
│   ├── diagrams
│   └── exports
├── aws
│   ├── deployment
│   ├── networking
│   ├── security
│   ├── monitoring
│   └── screenshots
├── azure
│   ├── deployment
│   ├── networking
│   ├── security
│   ├── monitoring
│   └── screenshots
├── gcp
│   ├── deployment
│   ├── networking
│   ├── security
│   ├── monitoring
│   └── screenshots
├── docs
├── scripts
└── evidence
```

## Portfolio Value

This project demonstrates:

- Cloud networking
- Linux administration
- Web server deployment
- IAM security practices
- Secure storage configuration
- Monitoring dashboards
- Alerting and notification workflows
- Audit logging
- Enterprise documentation
- Multi-cloud design thinking

## Interview Talking Point

A concise explanation for interviews:

> I designed and deployed an enterprise web platform on AWS using a custom VPC, public subnet, Internet Gateway, EC2 web server, S3 storage, IAM role, CloudWatch monitoring, SNS alerting, and CloudTrail auditing. The project demonstrates how I build secure, observable, and documented cloud infrastructure rather than only launching individual resources.

## Current Project Status

| Area | Status |
|---|---|
| AWS Implementation | Complete |
| AWS Documentation | Complete |
| AWS Evidence Index | Complete |
| AWS Architecture Source | Complete |
| Azure Equivalent Design | Complete |
| GCP Equivalent Design | Complete |
| Final README | Complete |
