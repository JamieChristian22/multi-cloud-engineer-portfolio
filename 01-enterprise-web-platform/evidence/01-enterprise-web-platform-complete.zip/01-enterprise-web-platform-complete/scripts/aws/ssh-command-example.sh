#!/bin/bash
# Replace PUBLIC_IPV4_ADDRESS with the current EC2 public IPv4 address.

chmod 400 ~/Downloads/enterprise-web-key-2.pem
ssh -i ~/Downloads/enterprise-web-key-2.pem ec2-user@PUBLIC_IPV4_ADDRESS
