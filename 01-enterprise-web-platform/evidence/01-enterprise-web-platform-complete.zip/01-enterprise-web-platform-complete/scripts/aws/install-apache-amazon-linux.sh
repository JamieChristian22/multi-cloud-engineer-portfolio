#!/bin/bash
set -e

sudo dnf update -y
sudo dnf install -y httpd
sudo systemctl enable httpd
sudo systemctl start httpd

sudo tee /var/www/html/index.html > /dev/null <<'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enterprise Web Platform</title>
    <style>
        body {
            background: #0f172a;
            color: white;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 80px;
        }
        h1 { font-size: 48px; }
        h2 { color: #38bdf8; }
        p { font-size: 22px; }
    </style>
</head>
<body>
    <h1>Enterprise Web Platform</h1>
    <h2>AWS Deployment</h2>
    <p>Jamie Christian II</p>
    <p>Running on Amazon EC2</p>
    <p>Project 01 — Multi-Cloud Engineering Projects</p>
</body>
</html>
EOF

sudo systemctl status httpd --no-pager
