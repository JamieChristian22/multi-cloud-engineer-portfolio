# AWS Evidence Index

This file lists the complete screenshot evidence set for the AWS implementation.

| # | Filename | Evidence Captured |
|---:|---|---|
| 01 | `01-aws-vpc-created.png` | Custom VPC created |
| 02 | `02-aws-public-subnet-created.png` | Public subnet created |
| 03 | `03-aws-internet-gateway-attached.png` | Internet Gateway attached |
| 04 | `04-aws-public-route-table.png` | Route table with default route to IGW |
| 05 | `05-aws-security-group-rules.png` | Security Group inbound and outbound rules |
| 06 | `06-aws-ec2-instance-running.png` | EC2 instance running with status checks passed |
| 07 | `07-aws-ssh-session.png` | SSH session from Mac Terminal |
| 08 | `08-aws-apache-running.png` | Apache service active and running |
| 09 | `09-aws-web-application-live.png` | Live web application in browser |
| 10 | `10-aws-s3-secure-storage.png` | S3 bucket private, encrypted, and versioned |
| 11 | `11-aws-iam-role-attached.png` | IAM role attached to EC2 |
| 12 | `12-aws-cloudwatch-dashboard.png` | CloudWatch dashboard |
| 13 | `13-aws-cloudwatch-alarm.png` | CloudWatch CPU alarm |
| 14 | `14-aws-sns-topic.png` | SNS topic |
| 15 | `15-aws-sns-subscription.png` | Confirmed email subscription |
| 16 | `16-aws-sns-test-email.png` | Test email received |
| 17 | `17-aws-cloudtrail-trail.png` | CloudTrail trail logging |
| 18 | `18-aws-cloudtrail-event-history.png` | CloudTrail event history |

## Evidence Standard

Each screenshot should show the resource name, status, and configuration details whenever possible. Sensitive values such as account IDs, email addresses, and IP addresses may be blurred before uploading to GitHub.
