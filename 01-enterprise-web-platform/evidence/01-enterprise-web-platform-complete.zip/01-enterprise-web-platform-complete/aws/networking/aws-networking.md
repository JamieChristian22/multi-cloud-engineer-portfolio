# AWS Networking Documentation

## Network Objective

The AWS networking layer provides a dedicated, isolated environment for the Enterprise Web Platform. The design separates project infrastructure from the default VPC and uses explicit routing and firewall rules.

## Network CIDR Plan

| Component | CIDR |
|---|---|
| VPC | `10.10.0.0/16` |
| Public Subnet | `10.10.1.0/24` |

## VPC

| Setting | Value |
|---|---|
| Name | `enterprise-web-vpc` |
| CIDR | `10.10.0.0/16` |
| Purpose | Isolated network boundary for the web platform |

## Public Subnet

| Setting | Value |
|---|---|
| Name | `enterprise-web-public-subnet` |
| CIDR | `10.10.1.0/24` |
| Availability Zone | `us-east-1a` |
| Purpose | Hosts internet-facing EC2 resources |

## Internet Gateway

| Setting | Value |
|---|---|
| Name | `enterprise-web-igw` |
| Attached VPC | `enterprise-web-vpc` |
| Purpose | Enables inbound and outbound internet connectivity |

## Route Table

| Setting | Value |
|---|---|
| Name | `enterprise-web-public-rt` |
| Associated Subnet | `enterprise-web-public-subnet` |

Routes:

| Destination | Target |
|---|---|
| `10.10.0.0/16` | Local |
| `0.0.0.0/0` | Internet Gateway |

## Security Group

Security Group:

```text
enterprise-web-sg
```

Inbound rules:

| Protocol | Port | Source | Justification |
|---|---:|---|---|
| TCP | 80 | `0.0.0.0/0` | Public HTTP web access |
| TCP | 443 | `0.0.0.0/0` | Public HTTPS-ready access |
| TCP | 22 | My IP | Secure administrative SSH access |

Outbound rules:

| Protocol | Destination | Justification |
|---|---|---|
| All traffic | `0.0.0.0/0` | Allows updates, package installs, and AWS service communication |

## Traffic Flow

```text
User Browser
    ↓ HTTP/80
Internet
    ↓
Internet Gateway
    ↓
Public Route Table
    ↓
Public Subnet
    ↓
Security Group
    ↓
EC2 Apache Web Server
```

## Network Validation

The network was validated by:

- Confirming EC2 received a public IPv4 address.
- Confirming the instance was running in the custom VPC.
- Confirming the instance was placed in `enterprise-web-public-subnet`.
- Confirming HTTP traffic reached Apache.
- Confirming SSH connectivity worked after security group and public IP configuration were correct.

## Troubleshooting Notes

### SSH Timeout

An SSH timeout usually means the instance is unreachable over port 22. The main checks are:

- Confirm EC2 has a public IPv4 address.
- Confirm Security Group allows SSH from the administrator's IP.
- Confirm the route table has `0.0.0.0/0` pointing to the Internet Gateway.
- Confirm the subnet is associated with the correct public route table.
- Confirm the instance is running and status checks are passing.

### Website Not Loading

If the website does not load:

- Confirm Security Group allows HTTP port 80.
- Confirm Apache is running with `sudo systemctl status httpd`.
- Confirm the public IPv4 address is correct.
- Confirm the instance is in the public subnet.
- Confirm the route table points to the Internet Gateway.
