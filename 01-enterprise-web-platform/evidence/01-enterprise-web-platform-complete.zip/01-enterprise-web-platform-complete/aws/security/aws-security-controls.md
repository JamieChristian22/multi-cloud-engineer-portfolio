# AWS Security Controls

## Security Objective

The security design protects the Enterprise Web Platform by controlling network access, avoiding long-term credentials on the server, securing object storage, and enabling audit logging.

## Security Group Controls

Security Group:

```text
enterprise-web-sg
```

Rules:

| Rule | Security Purpose |
|---|---|
| HTTP 80 from `0.0.0.0/0` | Allows public users to access the web application |
| HTTPS 443 from `0.0.0.0/0` | Prepares the platform for secure HTTPS traffic |
| SSH 22 from My IP | Restricts administrative access to the administrator's current IP |
| Outbound all traffic | Allows server updates and service communication |

## SSH Key Pair Authentication

Key pair used:

```text
enterprise-web-key-2.pem
```

Security controls:

- Private key remains on the administrator's Mac.
- File permissions are restricted with `chmod 400`.
- Key file is never committed to GitHub.
- SSH access is controlled by Security Group source restriction.

macOS permission command:

```bash
chmod 400 ~/Downloads/enterprise-web-key-2.pem
```

## IAM Role Security

Role name:

```text
enterprise-web-ec2-monitoring-role
```

Trusted entity:

```text
Amazon EC2
```

Attached policy:

```text
CloudWatchAgentServerPolicy
```

Security benefit:

The EC2 instance uses temporary credentials provided through the instance metadata service. This avoids storing AWS access keys directly on the server.

## S3 Security

Storage bucket security configuration:

| Control | Configuration |
|---|---|
| Block Public Access | Enabled |
| Object Ownership | ACLs disabled |
| Versioning | Enabled |
| Encryption | SSE-S3 |
| Public Access | Blocked |

Security benefit:

The bucket is protected from public exposure, supports object recovery through versioning, and encrypts stored data.

## CloudTrail Audit Logging

Trail name:

```text
enterprise-web-cloudtrail
```

Configuration:

| Control | Configuration |
|---|---|
| Multi-region trail | Enabled |
| Management events | Read and Write |
| Log file validation | Enabled |
| S3 log storage | Enabled |
| Data events | Not enabled in this project |

Security benefit:

CloudTrail records administrative and API activity. This supports investigations, change tracking, governance, and compliance review.

## Monitoring Security

CloudWatch and SNS provide operational security by alerting administrators about abnormal infrastructure conditions.

Alarm:

```text
enterprise-web-high-cpu-alarm
```

Notification topic:

```text
enterprise-web-alerts
```

Security benefit:

Administrators receive email notifications when monitored conditions exceed thresholds, allowing faster response to operational issues.

## Security Review

| Area | Status |
|---|---|
| Public access limited to web ports | Implemented |
| Administrative access restricted | Implemented |
| IAM role used instead of static keys | Implemented |
| S3 public access blocked | Implemented |
| S3 encryption enabled | Implemented |
| Audit logging enabled | Implemented |
| Monitoring alarms enabled | Implemented |
| Email notifications validated | Implemented |

## Production Improvements

For a production deployment, the following would be added:

- Application Load Balancer
- HTTPS certificate using AWS Certificate Manager
- AWS WAF
- Systems Manager Session Manager to replace SSH
- AWS Config rules
- GuardDuty threat detection
- Security Hub posture management
- KMS customer-managed encryption keys
- Centralized log archive account
