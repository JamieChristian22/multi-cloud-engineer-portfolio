# AWS Monitoring and Alerting

## Monitoring Objective

The monitoring layer provides visibility into server health, network activity, system status, and alert delivery for the Enterprise Web Platform.

## CloudWatch Dashboard

Dashboard name:

```text
enterprise-web-dashboard
```

Dashboard widgets:

| Widget | Metric | Purpose |
|---|---|---|
| EC2 CPU Utilization | `CPUUtilization` | Tracks server workload |
| EC2 Network In | `NetworkIn` | Tracks incoming network traffic |
| EC2 Network Out | `NetworkOut` | Tracks outgoing network traffic |
| EC2 Status Checks | `StatusCheckFailed` | Tracks infrastructure and instance health |

## CloudWatch Alarm

Alarm name:

```text
enterprise-web-high-cpu-alarm
```

Configuration:

| Setting | Value |
|---|---|
| Metric | EC2 CPUUtilization |
| Statistic | Average |
| Period | 5 minutes |
| Threshold | Greater than 70% |
| Action | Send notification to SNS |
| SNS Topic | `enterprise-web-alerts` |

Operational purpose:

The alarm detects sustained CPU pressure and notifies administrators before users experience major performance issues.

## Amazon SNS

Topic name:

```text
enterprise-web-alerts
```

Configuration:

| Setting | Value |
|---|---|
| Topic Type | Standard |
| Protocol | Email |
| Subscription Status | Confirmed |
| Test Message | Sent and received |

Validation:

A test SNS message was published and delivered by email, confirming that the notification workflow functions correctly.

## Alert Flow

```text
EC2 Metric
    ↓
CloudWatch Alarm
    ↓
SNS Topic
    ↓
Email Notification
    ↓
Administrator Response
```

## Operational Runbook

### High CPU Alarm Response

When `enterprise-web-high-cpu-alarm` enters the ALARM state:

1. Open CloudWatch alarm details.
2. Confirm the EC2 instance involved.
3. Review CPU utilization trend.
4. Check Apache service status.
5. SSH into the instance if needed.
6. Run basic Linux diagnostics:

```bash
uptime
top
df -h
free -m
sudo systemctl status httpd
```

7. Review recent application changes.
8. Restart Apache if the service is unhealthy:

```bash
sudo systemctl restart httpd
```

9. Document the incident and resolution.

## Monitoring Validation

The monitoring configuration is complete when:

- CloudWatch dashboard exists.
- Dashboard includes CPU and network metrics.
- CloudWatch alarm exists.
- SNS topic exists.
- Email subscription is confirmed.
- Test email has been received.
