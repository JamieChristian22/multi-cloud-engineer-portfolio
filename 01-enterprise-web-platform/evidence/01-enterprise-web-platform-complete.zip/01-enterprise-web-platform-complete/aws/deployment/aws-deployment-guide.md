# AWS Deployment Guide — Enterprise Web Platform

## Objective

Deploy an enterprise-style web platform on AWS using a custom network, EC2 web server, secure storage, monitoring, alerting, and audit logging.

## Region

Primary AWS region:

```text
us-east-1
US East (N. Virginia)
```

## Step 1 — Create the VPC

Create a custom VPC.

Configuration:

| Setting | Value |
|---|---|
| Name | `enterprise-web-vpc` |
| CIDR | `10.10.0.0/16` |
| Tenancy | Default |

Purpose:

The VPC provides an isolated network boundary for the Enterprise Web Platform.

Evidence screenshot:

```text
aws/screenshots/01-aws-vpc-created.png
```

## Step 2 — Create the Public Subnet

Create a public subnet inside the VPC.

Configuration:

| Setting | Value |
|---|---|
| Name | `enterprise-web-public-subnet` |
| VPC | `enterprise-web-vpc` |
| CIDR | `10.10.1.0/24` |
| Availability Zone | `us-east-1a` |

Purpose:

The public subnet hosts the EC2 web server and allows internet-facing access through the Internet Gateway.

Evidence screenshot:

```text
aws/screenshots/02-aws-public-subnet-created.png
```

## Step 3 — Create the Internet Gateway

Create and attach an Internet Gateway.

Configuration:

| Setting | Value |
|---|---|
| Name | `enterprise-web-igw` |
| Attached VPC | `enterprise-web-vpc` |

Purpose:

The Internet Gateway allows internet traffic to reach resources in the public subnet.

Evidence screenshot:

```text
aws/screenshots/03-aws-internet-gateway-attached.png
```

## Step 4 — Create the Public Route Table

Create a public route table and associate it with the public subnet.

Configuration:

| Setting | Value |
|---|---|
| Name | `enterprise-web-public-rt` |
| VPC | `enterprise-web-vpc` |
| Route | `0.0.0.0/0 → enterprise-web-igw` |
| Subnet Association | `enterprise-web-public-subnet` |

Purpose:

The route table sends internet-bound traffic from the public subnet to the Internet Gateway.

Evidence screenshot:

```text
aws/screenshots/04-aws-public-route-table.png
```

## Step 5 — Create the Security Group

Create a Security Group for the EC2 web server.

Configuration:

| Setting | Value |
|---|---|
| Name | `enterprise-web-sg` |
| Description | Controls inbound and outbound traffic for the Enterprise Web Platform |
| VPC | `enterprise-web-vpc` |

Inbound rules:

| Type | Port | Source | Purpose |
|---|---:|---|---|
| HTTP | 80 | `0.0.0.0/0` | Allow public web traffic |
| HTTPS | 443 | `0.0.0.0/0` | Allow secure web traffic |
| SSH | 22 | My IP | Allow administrative access |

Outbound rules:

| Type | Destination |
|---|---|
| All traffic | `0.0.0.0/0` |

Evidence screenshot:

```text
aws/screenshots/05-aws-security-group-rules.png
```

## Step 6 — Launch the EC2 Instance

Launch an Amazon Linux EC2 instance.

Configuration:

| Setting | Value |
|---|---|
| Name | `enterprise-web-ec2` |
| AMI | Amazon Linux 2023 |
| Instance Type | `t2.micro` |
| VPC | `enterprise-web-vpc` |
| Subnet | `enterprise-web-public-subnet` |
| Auto-assign Public IP | Enabled |
| Security Group | `enterprise-web-sg` |
| Key Pair | `enterprise-web-key-2.pem` |
| Storage | 8 GiB gp3 |

Purpose:

The EC2 instance hosts the Apache web server for the project.

Evidence screenshot:

```text
aws/screenshots/06-aws-ec2-instance-running.png
```

## Step 7 — Connect by SSH and Install Apache

From macOS Terminal, connect to the instance:

```bash
chmod 400 ~/Downloads/enterprise-web-key-2.pem
ssh -i ~/Downloads/enterprise-web-key-2.pem ec2-user@PUBLIC_IPV4_ADDRESS
```

Install and start Apache:

```bash
sudo dnf update -y
sudo dnf install -y httpd
sudo systemctl enable httpd
sudo systemctl start httpd
sudo systemctl status httpd
```

Create the application page:

```bash
sudo tee /var/www/html/index.html > /dev/null <<'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enterprise Web Platform</title>
    <style>
        body {
            background: #0f172a;
            color: white;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 80px;
        }
        h1 { font-size: 48px; }
        h2 { color: #38bdf8; }
        p { font-size: 22px; }
    </style>
</head>
<body>
    <h1>Enterprise Web Platform</h1>
    <h2>AWS Deployment</h2>
    <p>Jamie Christian II</p>
    <p>Running on Amazon EC2</p>
    <p>Project 01 — Multi-Cloud Engineering Projects</p>
</body>
</html>
EOF
```

Validate the site:

```text
http://PUBLIC_IPV4_ADDRESS
```

Evidence screenshots:

```text
aws/screenshots/07-aws-ssh-session.png
aws/screenshots/08-aws-apache-running.png
aws/screenshots/09-aws-web-application-live.png
```

## Step 8 — Create Secure S3 Storage

Create a private S3 bucket.

Recommended name:

```text
enterprise-web-storage-jcii-001
```

Configuration:

| Setting | Value |
|---|---|
| Object Ownership | ACLs disabled |
| Block Public Access | Enabled |
| Versioning | Enabled |
| Default Encryption | SSE-S3 |
| Public Access | Blocked |

Upload a validation file:

```text
enterprise-platform-test.txt
```

Example file content:

```text
Enterprise Web Platform
AWS Storage Validation
Project 01
Jamie Christian II
```

Evidence screenshot:

```text
aws/screenshots/10-aws-s3-secure-storage.png
```

## Step 9 — Create and Attach the IAM Role

Create an IAM role for EC2.

Configuration:

| Setting | Value |
|---|---|
| Role Name | `enterprise-web-ec2-monitoring-role` |
| Trusted Entity | EC2 |
| Attached Policy | `CloudWatchAgentServerPolicy` |

Attach the role to the EC2 instance:

```text
EC2 → Instances → enterprise-web-ec2 → Actions → Security → Modify IAM Role
```

Purpose:

The IAM role allows the instance to interact with AWS services without static credentials.

Evidence screenshot:

```text
aws/screenshots/11-aws-iam-role-attached.png
```

## Step 10 — Create CloudWatch Dashboard

Create a CloudWatch dashboard.

Dashboard name:

```text
enterprise-web-dashboard
```

Widgets:

| Widget | Metric |
|---|---|
| EC2 CPU Utilization | `CPUUtilization` |
| EC2 Network In | `NetworkIn` |
| EC2 Network Out | `NetworkOut` |
| EC2 Status Checks | `StatusCheckFailed` |

Purpose:

The dashboard provides operational visibility into the web server.

Evidence screenshot:

```text
aws/screenshots/12-aws-cloudwatch-dashboard.png
```

## Step 11 — Create CloudWatch Alarm

Create a CPU alarm.

Configuration:

| Setting | Value |
|---|---|
| Alarm Name | `enterprise-web-high-cpu-alarm` |
| Metric | `CPUUtilization` |
| Statistic | Average |
| Period | 5 minutes |
| Threshold | Greater than 70% |
| Notification | SNS topic `enterprise-web-alerts` |

Purpose:

The alarm identifies high CPU usage and sends an alert to administrators.

Evidence screenshot:

```text
aws/screenshots/13-aws-cloudwatch-alarm.png
```

## Step 12 — Configure SNS Notification Delivery

Create or validate SNS.

Configuration:

| Setting | Value |
|---|---|
| Topic Name | `enterprise-web-alerts` |
| Topic Type | Standard |
| Protocol | Email |
| Subscription Status | Confirmed |

Publish a test message:

Subject:

```text
Enterprise Web Platform Test Alert
```

Message:

```text
Enterprise Web Platform

AWS Project 01

This is a test notification generated from Amazon SNS.

If you received this message, the notification service has been successfully configured.

Jamie Christian II
```

Evidence screenshots:

```text
aws/screenshots/14-aws-sns-topic.png
aws/screenshots/15-aws-sns-subscription.png
aws/screenshots/16-aws-sns-test-email.png
```

## Step 13 — Enable CloudTrail

Create a CloudTrail trail.

Configuration:

| Setting | Value |
|---|---|
| Trail Name | `enterprise-web-cloudtrail` |
| Scope | All current and future regions |
| Management Events | Read and Write |
| Log File Validation | Enabled |
| Data Events | Not enabled for this project |
| Insights Events | Disabled |
| S3 Destination | `enterprise-web-cloudtrail-logs-jcii` |

Purpose:

CloudTrail provides audit visibility into API actions and administrative changes.

Evidence screenshots:

```text
aws/screenshots/17-aws-cloudtrail-trail.png
aws/screenshots/18-aws-cloudtrail-event-history.png
```

## AWS Completion Summary

The AWS implementation is complete when the following are true:

- The web application loads over HTTP.
- EC2 is running in the custom VPC and public subnet.
- Security Group allows web traffic and restricted SSH.
- S3 storage is private, encrypted, and versioned.
- IAM role is attached to EC2.
- CloudWatch dashboard displays metrics.
- CloudWatch alarm is configured.
- SNS test email is received.
- CloudTrail is logging management events.
