# Future Improvements

## Application Load Balancer

Add an Application Load Balancer in front of EC2 to improve traffic management and prepare the platform for multiple instances.

## Auto Scaling Group

Add an Auto Scaling Group to automatically replace unhealthy instances and scale based on demand.

## HTTPS with ACM

Use AWS Certificate Manager to issue an SSL/TLS certificate and serve the application over HTTPS.

## AWS WAF

Add AWS WAF to protect the web application from common web attacks.

## Systems Manager Session Manager

Replace direct SSH access with AWS Systems Manager Session Manager for more secure administrative access.

## AWS Backup

Add backup policies for EC2 and supporting storage resources.

## AWS Config

Track resource configuration changes and enforce compliance rules.

## GuardDuty and Security Hub

Add threat detection and centralized security posture visibility.

## Infrastructure as Code

Convert the manual deployment into Terraform for repeatability and version control.
