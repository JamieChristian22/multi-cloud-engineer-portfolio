# Cost Estimate

## Purpose

This file documents expected cost considerations for the Enterprise Web Platform.

## AWS Cost Areas

| Service | Cost Consideration |
|---|---|
| EC2 t2.micro | Free Tier eligible in many accounts; otherwise hourly cost applies |
| EBS Volume | Storage cost based on provisioned GB |
| S3 Storage | Cost based on storage used and requests |
| CloudWatch | Basic metrics included; dashboards and alarms may have small charges |
| SNS | Email notifications are low cost for project usage |
| CloudTrail | Management events typically available with event history; S3 storage costs apply for trail logs |

## Cost-Control Practices

- Use Free Tier instance size where possible.
- Stop or terminate EC2 when not actively needed.
- Delete unused S3 objects and old log buckets when finished.
- Use AWS Budgets in future versions.
- Avoid enabling high-volume data events unless required.

## Estimated Project Cost

For a small portfolio project with one EC2 instance, one S3 bucket, one dashboard, one alarm, and CloudTrail logs, expected cost should remain low if resources are cleaned up after use.

## Production Cost Additions

A production version would add cost for:

- Application Load Balancer
- Auto Scaling Group
- NAT Gateway
- WAF
- AWS Config
- GuardDuty
- Backups
- Route 53 hosted zone
- ACM certificate
