# Troubleshooting Guide

## SSH Operation Timed Out

Cause:

The instance cannot be reached on port 22.

Fix checklist:

1. Confirm the instance is running.
2. Confirm status checks show 2/2 passed.
3. Confirm the instance has a public IPv4 address.
4. Confirm Security Group allows SSH from your IP.
5. Confirm subnet route table has `0.0.0.0/0` to Internet Gateway.
6. Confirm the instance is in the intended public subnet.

## Permission Denied Public Key

Cause:

Wrong key file, wrong username, or wrong file permissions.

Fix:

```bash
chmod 400 ~/Downloads/enterprise-web-key-2.pem
ssh -i ~/Downloads/enterprise-web-key-2.pem ec2-user@PUBLIC_IPV4_ADDRESS
```

For Amazon Linux 2023, the username is:

```text
ec2-user
```

## Website Does Not Load

Cause:

Apache may not be running or port 80 may be blocked.

Fix:

```bash
sudo systemctl status httpd
sudo systemctl restart httpd
```

Also confirm Security Group allows inbound HTTP port 80 from `0.0.0.0/0`.

## CloudWatch Alarm Shows Insufficient Data

Cause:

New alarms may need time to receive metrics.

Fix:

Wait several minutes and refresh. Confirm the correct instance metric is selected.

## SNS Email Not Received

Cause:

Email subscription may still be pending.

Fix:

Open email inbox and confirm the SNS subscription.
