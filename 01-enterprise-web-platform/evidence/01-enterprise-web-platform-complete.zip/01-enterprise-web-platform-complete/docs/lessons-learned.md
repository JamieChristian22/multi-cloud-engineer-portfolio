# Lessons Learned

## Key Lessons

## 1. VPC Selection Matters

When launching EC2, the instance must be placed in the correct custom VPC and subnet. Using the default VPC can cause confusion and prevents the project from matching the intended architecture.

## 2. Public IP and Routing Are Required for SSH

An EC2 instance must have a public IPv4 address, a public route table, an Internet Gateway route, and a Security Group allowing SSH in order to be reachable from a local Mac terminal.

## 3. Security Group Rules Are a Common Troubleshooting Point

SSH timeouts are often caused by missing or incorrect inbound rules. Restricting SSH to My IP is better than opening port 22 to the entire internet.

## 4. IAM Roles Are Better Than Access Keys

Attaching an IAM role to EC2 is safer than storing access keys on the instance. This is an important cloud security practice.

## 5. Monitoring Adds Portfolio Value

Deploying infrastructure is only part of cloud engineering. A strong project also includes operational visibility through dashboards, alarms, and notifications.

## 6. CloudTrail Demonstrates Enterprise Thinking

Audit logging shows awareness of compliance, governance, and incident investigation requirements.

## 7. Documentation Makes the Project Job-Ready

Clear documentation turns a lab into a portfolio project that can be explained in interviews and reviewed by hiring managers.
