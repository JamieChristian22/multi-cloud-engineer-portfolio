# Business Case — Enterprise Web Platform

## Company

Acme Retail Solutions

## Problem

The company needs a reliable and secure cloud platform for hosting a web application. The current approach depends on manual deployment and inconsistent infrastructure decisions, which creates operational risk.

## Business Requirements

- Host a web application in the cloud.
- Use a dedicated cloud network.
- Keep storage private and encrypted.
- Enable monitoring and alerting.
- Record administrative activity for audit purposes.
- Document all deployment decisions.
- Design the platform so equivalent patterns can be used on AWS, Azure, and GCP.

## Technical Requirements

- Custom cloud network
- Public application access
- Secure administrative access
- Object storage
- IAM-based access
- Monitoring dashboard
- Alert notifications
- Audit logging

## Solution

The solution uses AWS services to build the first completed implementation:

- Amazon VPC for networking
- EC2 for compute
- Apache for web hosting
- S3 for secure storage
- IAM role for service permissions
- CloudWatch for monitoring
- SNS for notifications
- CloudTrail for audit logging

## Business Value

This platform provides:

- Better visibility into infrastructure health
- Stronger security than default cloud settings
- Faster troubleshooting through monitoring and logs
- Repeatable design patterns for future cloud deployments
- A portfolio-ready example of real cloud engineering work
