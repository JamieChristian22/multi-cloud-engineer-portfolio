# Azure Networking Design

## Objective

Create an Azure networking design that mirrors the AWS network structure using Azure-native services.

## Network Design

| Component | Value |
|---|---|
| Virtual Network | `vnet-enterprise-web` |
| Address Space | `10.20.0.0/16` |
| Web Subnet | `subnet-web` |
| Subnet CIDR | `10.20.1.0/24` |
| Security Control | `nsg-enterprise-web` |

## Network Security Group Rules

| Rule | Port | Source | Purpose |
|---|---:|---|---|
| Allow HTTP | 80 | Internet | Web traffic |
| Allow HTTPS | 443 | Internet | Secure web traffic |
| Allow SSH/RDP | 22/3389 | Administrator IP | Administrative access when VM is used |

## Traffic Flow

```text
User
    ↓
Internet
    ↓
Azure App Service or VM
    ↓
Azure Monitor
```

## Design Note

For a portfolio-friendly implementation, Azure App Service is preferred because it demonstrates platform-as-a-service hosting. If using a VM, the network pattern more closely matches the AWS EC2 deployment.
