# Azure Monitoring Design

## Objective

Use Azure Monitor, Log Analytics, and Action Groups to monitor the Azure implementation of the Enterprise Web Platform.

## Metrics

Recommended metrics:

- App Service requests
- App Service response time
- HTTP 5xx errors
- CPU or memory usage
- Availability

## Alerts

Action Group:

```text
ag-enterprise-web-alerts
```

Alert examples:

- HTTP 5xx errors exceed threshold.
- App Service unavailable.
- High CPU utilization if using VM/App Service Plan.
- Resource health issue detected.

## Logs

Log Analytics Workspace:

```text
law-enterprise-web-platform
```

Purpose:

Centralize logs and support operational troubleshooting.
