# Azure Equivalent Deployment Guide — Enterprise Web Platform

## Objective

Design the Microsoft Azure equivalent of the Enterprise Web Platform using Azure-native services that map to the AWS deployment.

## Azure Service Mapping

| AWS Service | Azure Equivalent | Purpose |
|---|---|---|
| VPC | Virtual Network | Network isolation |
| Public Subnet | Subnet | Resource placement |
| Security Group | Network Security Group | Network firewall rules |
| EC2 | App Service or Virtual Machine | Web application hosting |
| S3 | Storage Account / Blob Storage | Object storage |
| IAM Role | Managed Identity / RBAC | Identity-based access |
| CloudWatch | Azure Monitor | Metrics and monitoring |
| CloudWatch Logs | Log Analytics Workspace | Log collection |
| SNS | Action Group | Alert notifications |
| CloudTrail | Activity Log | Audit activity |

## Recommended Azure Architecture

```text
Internet
    ↓
Azure App Service
    ↓
Azure Monitor
    ↓
Action Group Email Alert

Virtual Network
    ↓
Subnet
    ↓
Network Security Group

Storage Account
Key Vault
Log Analytics Workspace
Activity Log
```

## Resource Group

| Setting | Value |
|---|---|
| Name | `rg-enterprise-web-platform` |
| Region | East US |

## Virtual Network

| Setting | Value |
|---|---|
| Name | `vnet-enterprise-web` |
| Address Space | `10.20.0.0/16` |
| Subnet | `subnet-web` |
| Subnet CIDR | `10.20.1.0/24` |

## App Service

| Setting | Value |
|---|---|
| Name | `app-enterprise-web-jcii` |
| Runtime | Static HTML or Node/Python |
| Hosting Plan | Free or Basic |
| Purpose | Host web application |

## Storage Account

| Setting | Value |
|---|---|
| Name | `stenterprisewebjcii` |
| Replication | LRS |
| Secure Transfer | Enabled |
| Public Access | Disabled |

## Key Vault

| Setting | Value |
|---|---|
| Name | `kv-enterprise-web-jcii` |
| Purpose | Store secrets and application configuration |

Sample secret:

```text
app-environment = production
```

## Monitoring

Azure Monitor should track:

- App Service requests
- HTTP server errors
- CPU or application usage
- Availability
- Activity Log events

## Alerting

Action Group:

```text
ag-enterprise-web-alerts
```

Alert rules:

- High HTTP 5xx count
- App Service availability issue
- Resource health degraded

## Evidence Screenshots

Recommended Azure screenshots:

```text
azure/screenshots/01-azure-resource-group.png
azure/screenshots/02-azure-vnet-subnet.png
azure/screenshots/03-azure-nsg-rules.png
azure/screenshots/04-azure-app-service-live.png
azure/screenshots/05-azure-storage-account.png
azure/screenshots/06-azure-key-vault-secret.png
azure/screenshots/07-azure-monitor-alerts.png
azure/screenshots/08-azure-log-analytics.png
```

## Completion Criteria

The Azure equivalent is complete when the web app is reachable, storage is secured, monitoring is configured, alerts are connected to an Action Group, and activity logging is available.
