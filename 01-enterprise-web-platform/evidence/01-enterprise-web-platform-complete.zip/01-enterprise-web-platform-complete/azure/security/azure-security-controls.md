# Azure Security Controls

## Objective

Secure the Azure equivalent of the Enterprise Web Platform using RBAC, Network Security Groups, Key Vault, Storage security, and platform logging.

## Controls

| Area | Azure Control |
|---|---|
| Identity | Microsoft Entra ID and RBAC |
| Secrets | Azure Key Vault |
| Network | Network Security Group |
| Storage | Secure transfer and disabled public access |
| Monitoring | Azure Monitor |
| Logging | Log Analytics and Activity Log |
| Alerts | Action Groups |

## Storage Security

Storage Account controls:

- Secure transfer required.
- Public access disabled.
- Least-privilege access through RBAC.
- Private containers used by default.

## Key Vault

Key Vault stores application configuration and secrets. Application credentials should not be stored in source code.

## Production Improvements

- Private Endpoints
- Defender for Cloud
- Azure Policy
- Managed Identity
- WAF with Application Gateway or Front Door
