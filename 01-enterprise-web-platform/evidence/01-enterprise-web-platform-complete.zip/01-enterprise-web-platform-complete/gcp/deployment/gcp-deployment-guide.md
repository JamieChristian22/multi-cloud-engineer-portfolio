# GCP Equivalent Deployment Guide — Enterprise Web Platform

## Objective

Design the Google Cloud equivalent of the Enterprise Web Platform using GCP-native services that align with the AWS implementation.

## GCP Service Mapping

| AWS Service | GCP Equivalent | Purpose |
|---|---|---|
| VPC | VPC Network | Network isolation |
| Public Subnet | Subnet | Resource placement |
| Security Group | Firewall Rules | Network traffic control |
| EC2 | Compute Engine | Web application hosting |
| S3 | Cloud Storage | Object storage |
| IAM Role | IAM Service Account | Identity access |
| CloudWatch | Cloud Monitoring | Metrics |
| CloudWatch Logs | Cloud Logging | Logs |
| SNS | Alerting notification channel | Notifications |
| CloudTrail | Cloud Audit Logs | Audit logging |

## Recommended GCP Architecture

```text
Internet
    ↓
Compute Engine VM
    ↓
Apache Web Server

Cloud Storage
Cloud Monitoring
Cloud Logging
Cloud Audit Logs
IAM Service Account
```

## VPC Network

| Setting | Value |
|---|---|
| Name | `vpc-enterprise-web` |
| Subnet | `subnet-enterprise-web` |
| CIDR | `10.30.1.0/24` |
| Region | `us-central1` |

## Firewall Rules

| Rule | Port | Source | Purpose |
|---|---:|---|---|
| `allow-http-https` | 80, 443 | `0.0.0.0/0` | Web traffic |
| `allow-ssh-my-ip` | 22 | Administrator IP | SSH administration |

## Compute Engine

| Setting | Value |
|---|---|
| Name | `enterprise-web-vm` |
| Machine Type | `e2-micro` |
| Image | Debian or Ubuntu |
| External IP | Enabled |
| Network | `vpc-enterprise-web` |

## Web Server Commands

```bash
sudo apt update -y
sudo apt install apache2 -y
sudo systemctl enable apache2
sudo systemctl start apache2
```

Create web page:

```bash
echo "<h1>Enterprise Web Platform</h1><p>GCP Deployment</p>" | sudo tee /var/www/html/index.html
```

## Cloud Storage

| Setting | Value |
|---|---|
| Bucket | `enterprise-web-storage-jcii` |
| Public Access Prevention | Enabled |
| Uniform Bucket-Level Access | Enabled |
| Versioning | Enabled |

## Monitoring and Logging

Recommended monitoring:

- VM CPU utilization
- Network traffic
- VM uptime
- Apache health
- Log-based alerts

## Evidence Screenshots

Recommended GCP screenshots:

```text
gcp/screenshots/01-gcp-vpc-subnet.png
gcp/screenshots/02-gcp-firewall-rules.png
gcp/screenshots/03-gcp-compute-engine-running.png
gcp/screenshots/04-gcp-web-application-live.png
gcp/screenshots/05-gcp-cloud-storage-bucket.png
gcp/screenshots/06-gcp-cloud-monitoring-dashboard.png
gcp/screenshots/07-gcp-cloud-logging.png
```
