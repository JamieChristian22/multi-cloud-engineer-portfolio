# GCP Networking Design

## Objective

Create a GCP network design that mirrors the AWS VPC structure using GCP VPC, subnet, and firewall rules.

## Network Design

| Component | Value |
|---|---|
| VPC Network | `vpc-enterprise-web` |
| Subnet | `subnet-enterprise-web` |
| Subnet CIDR | `10.30.1.0/24` |
| Region | `us-central1` |

## Firewall Rules

| Rule | Ports | Source | Purpose |
|---|---|---|---|
| `allow-http-https` | `tcp:80,tcp:443` | `0.0.0.0/0` | Web access |
| `allow-ssh-my-ip` | `tcp:22` | Administrator IP | SSH access |

## Traffic Flow

```text
User Browser
    ↓
External IP
    ↓
GCP Firewall Rule
    ↓
Compute Engine VM
    ↓
Apache Web Server
```
