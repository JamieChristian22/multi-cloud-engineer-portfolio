# GCP Screenshots

Store validated project screenshots in this folder.

Screenshots should use the naming standard documented in the evidence index and deployment guides. Sensitive details such as account IDs, email addresses, or public IPs may be blurred before uploading to GitHub.
