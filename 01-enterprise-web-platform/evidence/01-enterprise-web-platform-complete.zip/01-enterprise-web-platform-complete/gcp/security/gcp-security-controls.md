# GCP Security Controls

## Objective

Secure the GCP equivalent of the Enterprise Web Platform using IAM, firewall rules, Cloud Storage controls, and audit logging.

## Controls

| Area | GCP Control |
|---|---|
| Identity | IAM and Service Accounts |
| Network | Firewall Rules |
| Storage | Cloud Storage public access prevention |
| Logging | Cloud Audit Logs |
| Monitoring | Cloud Monitoring |
| Alerts | Notification Channels |

## Cloud Storage Security

Recommended controls:

- Uniform bucket-level access enabled.
- Public access prevention enabled.
- Versioning enabled.
- IAM-based access only.

## Compute Engine Security

Recommended controls:

- SSH limited to administrator IP.
- Service account uses least privilege.
- OS Login considered for production environments.
- Firewall rules explicitly defined.
