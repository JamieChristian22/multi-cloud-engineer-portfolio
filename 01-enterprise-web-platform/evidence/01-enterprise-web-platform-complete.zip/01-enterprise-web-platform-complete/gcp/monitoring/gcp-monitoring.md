# GCP Monitoring Design

## Objective

Use Cloud Monitoring and Cloud Logging to monitor the GCP implementation of the Enterprise Web Platform.

## Metrics

Recommended metrics:

- VM CPU utilization
- Network ingress
- Network egress
- Uptime
- Instance status

## Dashboard

Dashboard name:

```text
enterprise-web-gcp-dashboard
```

Widgets:

- CPU utilization
- Network traffic
- VM uptime
- Log-based alert status

## Alerts

Recommended alert policies:

- High CPU utilization
- VM unavailable
- High error count in logs

## Logs

Cloud Logging should collect VM and system logs. For a production deployment, Apache logs can also be forwarded into Cloud Logging.
