# Enterprise Web Platform

## Project Overview
Enterprise-grade cloud engineering project demonstrating networking, compute, storage, IAM, monitoring, alerting, and audit logging on AWS with equivalent Azure and GCP implementations planned.

## Components
- Custom VPC
- Public Subnet
- Internet Gateway
- Route Tables
- Security Groups
- EC2 (Apache)
- IAM Role
- Amazon S3
- CloudWatch
- SNS
- CloudTrail

## Future Enhancements
- Application Load Balancer
- Auto Scaling Group
- AWS WAF
- AWS Systems Manager
- AWS Backup
- AWS Config
