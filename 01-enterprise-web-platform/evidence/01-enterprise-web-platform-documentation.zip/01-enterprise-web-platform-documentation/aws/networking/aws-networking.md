# AWS Networking

Describe VPC, subnets, routing, IGW, and Security Groups.