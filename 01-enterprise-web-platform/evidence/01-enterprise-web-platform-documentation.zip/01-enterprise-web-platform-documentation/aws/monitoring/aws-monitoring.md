# AWS Monitoring

CloudWatch dashboards, alarms, SNS notifications.