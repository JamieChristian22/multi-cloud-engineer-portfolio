# AWS Security Controls

IAM roles, S3 security, CloudTrail, Security Groups.