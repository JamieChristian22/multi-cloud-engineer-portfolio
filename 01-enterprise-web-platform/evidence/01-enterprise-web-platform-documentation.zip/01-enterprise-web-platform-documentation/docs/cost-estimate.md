# Cost Estimate

Free Tier estimate and production considerations.